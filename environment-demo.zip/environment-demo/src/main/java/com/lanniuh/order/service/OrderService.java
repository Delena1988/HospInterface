package com.lanniuh.order.service;

import com.lanniuh.order.model.Order;

/**
 * Created by linjian
 * 16/8/31.
 */
public interface OrderService {
    int insert(Order order);
}
