package com.lanniuh.order.dao;

import com.lanniuh.order.model.Order;

public interface OrderMapper {
    int insert(Order record);
}